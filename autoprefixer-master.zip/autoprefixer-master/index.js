require('babel-register')();
module.exports = require('./lib/autoprefixer');
